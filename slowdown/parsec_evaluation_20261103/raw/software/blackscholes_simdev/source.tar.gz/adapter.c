#define main parsec_file_main
#include "blackscholes.upstream.c"
#undef main
#include <stdint.h>
static float s[16],k[16],r[16],v[16],t[16],p[16]; static int ty[16];
static const OptionData in[16]={
 {42.00f,40.00f,0.1000f,0.00f,0.20f,0.50f,'C',0.00f,4.759423036851750055f},
 {42.00f,40.00f,0.1000f,0.00f,0.20f,0.50f,'P',0.00f,0.808600016880314021f},
 {100.00f,100.00f,0.0500f,0.00f,0.15f,1.00f,'P',0.00f,3.714602051381290071f},
 {100.00f,100.00f,0.0500f,0.00f,0.15f,1.00f,'C',0.00f,8.591659601309890704f},
 {60.00f,65.00f,0.0800f,0.00f,0.30f,0.25f,'C',0.00f,2.133371966735750025f},
 {100.00f,90.00f,0.1000f,0.00f,0.10f,0.10f,'C',0.00f,10.895610714793999563f},
 {100.00f,90.00f,0.1000f,0.00f,0.10f,0.50f,'C',0.00f,14.421570828843300660f},
 {100.00f,90.00f,0.1000f,0.00f,0.10f,1.00f,'C',0.00f,18.630859120667498274f},
 {100.00f,100.00f,0.1000f,0.00f,0.10f,0.10f,'C',0.00f,1.814984118378420108f},
 {100.00f,100.00f,0.1000f,0.00f,0.10f,0.50f,'C',0.00f,5.850273604284979889f},
 {100.00f,100.00f,0.1000f,0.00f,0.10f,1.00f,'C',0.00f,10.308147243666800463f},
 {100.00f,110.00f,0.1000f,0.00f,0.10f,0.10f,'C',0.00f,0.003523074865584340f},
 {100.00f,110.00f,0.1000f,0.00f,0.10f,0.50f,'C',0.00f,1.140722843827409960f},
 {100.00f,110.00f,0.1000f,0.00f,0.10f,1.00f,'C',0.00f,4.216747020308850402f},
 {100.00f,90.00f,0.1000f,0.00f,0.25f,0.10f,'C',0.00f,11.135244618346700207f},
 {100.00f,90.00f,0.1000f,0.00f,0.25f,0.50f,'C',0.00f,16.092638844092299166f},
};
void workload_prepare(void) {numOptions=16;nThreads=1;data=(OptionData*)in;prices=p;sptprice=s;strike=k;rate=r;volatility=v;otime=t;otype=ty;
for(int i=0;i<16;i++){s[i]=in[i].s;k[i]=in[i].strike;r[i]=in[i].r;v[i]=in[i].v;t[i]=in[i].t;ty[i]=(in[i].OptionType=='P');}}
void workload_run(void){int tid=0;bs_thread(&tid);}
int workload_verify(void){uint64_t h=14695981039346656037ULL;int ok=1;for(int i=0;i<16;i++){union{float f;uint32_t u;}x={p[i]};float d=fabsf(p[i]-in[i].DGrefval);if(!isfinite(p[i])||d>=0.0001f)ok=0;h^=x.u;h*=1099511628211ULL;}
printf("[OUTPUT] benchmark=blackscholes checksum=%016lx verified=%d options=16 runs=%d\n",(unsigned long)h,ok,NUM_RUNS);return ok;}
