#include <stdint.h>
#include <stdio.h>
#include <math.h>
#include "location_t.h"
#include "netlist_elem.h"
#include "netlist.h"
#include "annealer_thread.h"
extern const char eval_netlist[] = R"NET(100	15	15
a	1	af	n	ce	cs	a	END
b	2	p	x	bj	ap	aa	END
c	1	t	af	cm	br	z	END
d	2	t	by	ba	ag	bv	END
e	1	ak	t	at	bm	cu	END
f	1	i	aw	bt	d	ak	END
g	1	ah	bd	ch	w	ap	END
h	1	p	ae	aq	e	l	END
i	2	an	f	ah	cn	cq	END
j	1	am	r	bv	cf	ch	END
k	2	aw	by	am	l	ay	END
l	2	cg	aj	ch	d	v	END
m	2	cm	a	ca	m	bu	END
n	1	by	ao	bf	bq	bp	END
o	2	ac	bx	c	s	cf	END
p	2	am	bt	bf	ag	cs	END
q	1	u	m	ce	w	e	END
r	2	ba	n	ce	bq	u	END
s	1	bc	ak	ay	cu	cg	END
t	1	as	cf	ak	cu	cj	END
u	2	ap	bu	ac	au	af	END
v	2	z	bc	f	au	aw	END
w	1	az	bo	bd	bc	ar	END
x	1	t	j	bw	ba	bj	END
y	1	cj	aa	ap	b	aw	END
z	1	cr	o	u	bo	m	END
aa	2	o	cc	t	bp	v	END
ab	2	bp	bd	af	ca	al	END
ac	1	br	bc	bz	bn	av	END
ad	1	an	w	av	bl	at	END
ae	2	bi	cn	ab	d	m	END
af	2	ct	o	x	ax	i	END
ag	1	bw	ar	s	b	z	END
ah	1	cs	bm	at	b	q	END
ai	2	p	co	bm	cu	z	END
aj	1	bp	av	cd	o	b	END
ak	1	bg	bc	ac	cg	o	END
al	2	bq	aq	d	bz	ch	END
am	1	bd	k	o	g	u	END
an	1	bm	bb	cp	ai	ay	END
ao	1	cl	ac	bj	bz	ar	END
ap	1	ak	p	bu	cg	cg	END
aq	1	ai	bv	cu	cu	j	END
ar	2	cs	cr	ay	o	av	END
as	1	bu	ci	cd	aw	ag	END
at	1	ai	i	bd	bj	cm	END
au	2	af	q	aw	s	bv	END
av	2	aw	co	cv	d	ab	END
aw	1	u	cs	ah	ae	bf	END
ax	2	ah	a	ah	cf	cb	END
ay	2	al	b	g	br	cr	END
az	2	f	f	cj	e	a	END
ba	1	b	bd	ck	bj	bi	END
bb	1	cl	k	au	ba	cc	END
bc	2	as	a	cv	bb	j	END
bd	2	cc	cv	cd	f	ao	END
be	2	ax	cf	bp	br	u	END
bf	2	bo	bq	bm	cl	f	END
bg	1	cn	be	s	cu	bs	END
bh	1	au	au	as	aq	cr	END
bi	1	az	at	bq	ah	co	END
bj	2	bx	ac	g	h	ce	END
bk	1	e	ch	az	m	au	END
bl	2	cu	y	bu	bi	x	END
bm	2	ae	q	r	bm	c	END
bn	1	p	bq	af	cb	bz	END
bo	1	ah	ah	cg	al	a	END
bp	2	cf	cd	cc	cu	z	END
bq	2	ba	bw	cr	p	co	END
br	2	bw	be	aj	q	cd	END
bs	1	bd	bq	ba	ar	bi	END
bt	1	by	cv	at	ak	c	END
bu	1	bj	h	r	h	ah	END
bv	1	p	cc	z	bo	cu	END
bw	1	am	v	bv	bx	bw	END
bx	2	cp	r	o	am	ap	END
by	2	q	k	co	ch	ct	END
bz	1	ao	w	ck	ar	cn	END
ca	1	cj	az	f	by	cj	END
cb	2	ct	cv	r	bl	ah	END
cc	2	bd	l	h	cs	cl	END
cd	1	ad	ab	m	l	v	END
ce	1	cn	s	be	o	bx	END
cf	1	k	ct	bu	co	cu	END
cg	2	bf	bf	cv	cl	bf	END
ch	2	at	o	ao	k	ap	END
ci	2	f	an	ap	w	by	END
cj	1	ck	al	bu	ay	s	END
ck	1	bl	be	cb	am	g	END
cl	1	cj	aj	co	ai	u	END
cm	2	as	cj	be	ch	o	END
cn	2	aa	ay	bq	ct	bu	END
co	2	br	bj	co	bi	ct	END
cp	1	m	d	an	ak	h	END
cq	2	aw	bb	ch	aj	j	END
cr	2	cs	cv	ah	ak	u	END
cs	1	ap	o	bw	y	o	END
ct	2	bl	cs	q	z	cl	END
cu	1	o	l	bc	cq	bj	END
cv	2	bh	cn	bt	ak	br	END
)NET";
static netlist *nl;static annealer_thread *worker;
extern "C" void workload_prepare(void){srandom(3);nl=new netlist("embedded");worker=new annealer_thread(nl,1,100,300,2);}
extern "C" void workload_run(void){worker->Run();}
extern "C" int workload_verify(void){double cost=nl->total_routing_cost();union{double f;uint64_t u;}x={cost};int ok=isfinite(cost)&&cost>=0;
printf("[OUTPUT] benchmark=canneal checksum=%016lx verified=%d routing_cost=%lu\n",(unsigned long)x.u,ok,(unsigned long)cost);return ok;}
