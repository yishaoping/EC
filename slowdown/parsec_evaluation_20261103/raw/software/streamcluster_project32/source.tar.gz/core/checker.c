#include "checker.h"

#include <stdio.h>

#include "../hw/ghe.h"
#include "../hw/ght.h"
#include "../hw/rocc.h"
#include "../cfg/config.h"

int checker(int hart_id)
{
    /* 初始化 GHE/GHT，完成 ELU 自检后等待 GHT 通道收敛。 */
    ghe_asR();
    ght_set_satp_priv();
    ghe_go();
    ghe_common_observer_init();
    ghe_initailised(1);

    ROCC_INSTRUCTION(1, 0x75);
    ROCC_INSTRUCTION(1, 0x73);
    ROCC_INSTRUCTION(1, 0x64);
    for (int sel_elu = 0; sel_elu < 2; sel_elu++) {
        ROCC_INSTRUCTION_S(1, sel_elu, 0x65);

        while (elu_checkstatus() != 0) {
            printf("[ERROR] checker=%x elu=%x status=error\n", hart_id,
                   sel_elu);
            ROCC_INSTRUCTION_S(1, sel_elu, 0x63);
        }
    }

    while (ghe_checkght_status() != 0x02) {
        if ((ghe_rsur_status() & 0x18) == 0x08) {
            ROCC_INSTRUCTION(1, 0x60);
            R_INSTRUCTION_JLR(3, 0x00);
        }
    }

    ROCC_INSTRUCTION(1, 0x72);
    ROCC_INSTRUCTION(1, 0x60);

    __asm__ volatile("nop");
    __asm__ volatile("nop");
    __asm__ volatile("nop");
    __asm__ volatile("nop");
    __asm__ volatile("nop");

    while (ghe_checkght_status() != 0x02) {
    }

    /* 先通知 GHT 当前 checker 已完成，避免统计读取阻塞完成同步。 */
    ghe_release();
    ght_unset_satp_priv();

    /* The common benchmark publishes completion without a statistics ABI. */
    return 0;
}
